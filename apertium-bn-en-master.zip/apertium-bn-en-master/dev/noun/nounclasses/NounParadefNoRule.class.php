<?php

// Empty Rule
class NounParadefNoRule extends NounInflectionRule{
    
    public function __construct($noun){
        parent::__construct($noun);
    }
    
    public function conjugateNominative(){
        
    }
    public function conjugateObjective(){
        
        
    }
    public function conjugateGenitive(){
        
        
    }
    public function conjugateLocative(){
        
    }
    
    public function conjugateMisc(){
        
    }
}

?>
